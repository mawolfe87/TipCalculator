package edu.dtcc.wolfe.michael.tipcalculator;
/*
Michael Wolfe
* Tip Calculator
* 2.23.2016
* */
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
//    Declare variables
    private double amount;
    private double baseTip;
    private double baseTotal;
    private double customTip = 18.00;
    private double customTotal;
    private double splitTip;
    private int tipPercent;
    private String strAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Create layout-object references, array adapter for the spinner
        GridLayout gL = (GridLayout)findViewById(R.id.gridLayout);
        gL.setUseDefaultMargins(false);
        final Spinner spinner = (Spinner)findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.numbers,
                android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        final TextView tvSplitAmt = (TextView)findViewById(R.id.tvSplitAmt);
//        DecimalFormat to display 0.00
        final DecimalFormat precision = new DecimalFormat("0.00");
        final EditText etAmount = (EditText)findViewById(R.id.etAmount);
        final SeekBar sbCustomPercent = (SeekBar)findViewById(R.id.sbCustomPercent);
        final TextView tvCustomPercent = (TextView)findViewById(R.id.tvCustomPercent);
        final TextView tvBaseTip = (TextView)findViewById(R.id.tvBaseTip);
        final TextView tvBaseTotal = (TextView)findViewById(R.id.tvBaseTotal);
        final TextView tvCustomTip = (TextView)findViewById(R.id.tvCustomTip);
        final TextView tvCustomTotal = (TextView)findViewById(R.id.tvCustomTotal);

//        Set the OnSeekBarChangeListener
        sbCustomPercent.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
//            OnProgressChanged method adjusts the default 18% custom gratuity and re-displays
//            the custom tip amount and custom total amount
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tipPercent = progress;
                tvCustomPercent.setText(tipPercent + "%");
                strAmount = etAmount.getText().toString();
                customTip = round(amount * ((double) tipPercent / 100.00), 2);
                customTotal = round((amount + customTip), 2);
                tvCustomTip.setText("$" + (precision.format(customTip)));
                tvCustomTotal.setText("$" + (precision.format(customTotal)));

            }

//            Not Used
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

//            Not Used
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

//        Set the TextChangedListener and use anonymous inner TextWatcher class to receive input
//        in the check amount field
        etAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

//            OnTextChanged calculates tip amount and check total with both customand base tip amount
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                strAmount = etAmount.getText().toString();
//                I found this if statement was needed to keep the app from crashing when deleting all
//                numbers in the check amount EditText
                if (strAmount.matches("")) {
                    tvBaseTip.setText("");
                    tvBaseTotal.setText("");
                    tvCustomTip.setText("");
                    tvCustomTotal.setText("");
                    tvSplitAmt.setText("");

                } else {
                    amount = Double.parseDouble(strAmount);
                    tipPercent = sbCustomPercent.getProgress();
                    baseTip = round((amount * 0.15), 2);
                    baseTotal = round((amount + baseTip), 2);
                    customTip = round(amount * ((double) tipPercent / 100.00), 2);
                    customTotal = round((amount + customTip), 2);
                    splitTip = customTip / (spinner.getSelectedItemPosition() + 1);

//                    Spinner ItemSelectedListener within the else of the previous anonymous class
                    AdapterView.OnItemSelectedListener onSpinner = new AdapterView.OnItemSelectedListener(){

                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            strAmount = etAmount.getText().toString();
//                            Checks for empty amount EditText and handles accordingly
                            if (strAmount.matches("")){
                                tvSplitAmt.setText("");
                            } else{
//                                Else, uses the spinner's selected position(+1) to add multiple people
                                double persons;
                                persons = ((double) position + 1);
                                splitTip = customTip / persons;
                                tvSplitAmt.setText("$" + (precision.format(splitTip)));
                            }

                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {
                            if (strAmount.matches("")){
                                tvSplitAmt.setText("");
                            } else{
                                double persons = 1;
                                splitTip = customTip / persons;
                                tvSplitAmt.setText("$" + (precision.format(splitTip)));
                            }
                        }
                    };
//                    Sets the individual TextViews to the correct tip variable, rounded half-way up
//                    and formatted to 2 decimals
                    spinner.setOnItemSelectedListener(onSpinner);
                    tvBaseTip.setText("$" + (precision.format(baseTip)));
                    tvBaseTotal.setText("$" + (precision.format(baseTotal)));
                    tvCustomTip.setText("$" + (precision.format(customTip)));
                    tvCustomTotal.setText("$" + (precision.format(customTotal)));
                    tvSplitAmt.setText("$" + (precision.format(splitTip)));
                }


            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
//    Round method used to round half-way up
    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}
